Created multiple data structures: Hash map, linked list, heap, and organized the hash map quadratic probing.
 